<?php
require "C:\Users\Michel\Downloads\wordpress-6.2.2 (1)\wordpress\wp-includes\Requests\src\autoload.php";

// $urlPrefix = '/braintree/';
// require_once 'braintree_php-master/lib/Braintree.php';
//set the sandbox credentials


?>